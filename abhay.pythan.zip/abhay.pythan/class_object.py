class person:
    name = "abhay"
    occupation = "software dewaloper"
    networth = "11213"
    def info(self):
        print(f"{self.name} is a {self.occupation} and his salary is {self.networth}")
    
a = person()
b = person()
c = person()

a.name ="pankaj"
print(a.name)
a.occupation = "devloper"
print(a.occupation)
a.networth = "75498"
print(a.networth) 
a.info()  

a.name ="subham"
print(a.name)
a.occupation = "domkey"
print(a.occupation)
a.networth = "754"
print(a.networth) 
a.info() 

b.name ="pankaj"
print(b.name)
b.occupation = " devloper"
print(b.occupation)
b.networth = "75498"
print(b.networth) 
b.info()   

c.name ="pankaj"
print(c.name)
c.occupation = " devloper"
print(c.occupation)
c.networth = "75498"
print(c.networth) 
c.info()  