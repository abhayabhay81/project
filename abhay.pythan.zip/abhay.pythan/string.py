"""
name="abhay"
print("hello "+ name)
print("he soid, \" i want to eat an apple\"")
print('he soid, \" i want to eat an apple\"')

#recept="""
#my name is abhay
#my name is amit
#my name is aman
#my name is arun
#my name is asmit"""

#print(recept)

#note='''
#my name is abhay
#my name is amit
#my name is aman
#my name is arun
#my name is asmit'''

#print(note)
"""
fruit = "Mango"
len1 = len(fruit)
print("Mango is a", len1, "letter word.")"""

pie="aGHGHHple MKJJanv !!!!!"
"""
print(pie[:4])
print(pie[6])
print(pie[:5])      #Slicing from Start
print(pie[5:])      #Slicing till End
print(pie[2:6])     #Slicing in between
print(pie[-8:])     #Slicing using negative index

for i in pie :
    print(i)
    
print(pie.upper())
print(pie.lower())

print(pie.strip())
print(pie.rstrip("!"))
print(pie.replace("MK", "new"))
print(pie.split(" "))"""

capstr1=pie.capitalize()
print(capstr1)








