"""
def funcsum(a, b):
  sum=(a+b)
  print("the sum is ",sum)
    
    
funcsum(4,6)
    
    
def func_name(a,b):
   return (a+b)

print(func_name(4, 5))

def func_name(a,b):
   return (a+b)

print(func_name(4, 5))
 

def calculateGmean(a, b):
  mean = (a*b)/(a+b)
  print(mean)
  
a = 9
b = 8

calculateGmean(a, b)

def func_name(a=1,b=5):
  sum=a+b
  print(sum)
  
func_name() """

def func_name(*a):
    print(type(a))
    
func_name(7)


        
