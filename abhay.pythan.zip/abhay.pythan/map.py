from functools import reduce

# this is map function 
"""
def cube(x):
    return x*x*x
l=[1,2,3,4,5,6]

newl=list(map(cube,l))
print(newl)

#map is use in list 

#filter

def funct(a):
    return a>4
newn=list(filter(funct,l))
print(newn)

def sum(x,y):
    return x+y

sum=reduce(sum,l)
print(sum)"""

"""
l=[1,2,3,4,5,6]
nex=list(map(lambda x : x*x*x,l))
print(nex)

nexn=list(filter(lambda a : a>4, l))
print(nexn)

sum=reduce(lambda x,y: x+y,l)
print(sum)"""