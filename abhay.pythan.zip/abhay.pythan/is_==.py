"""
a=5
b=6

a=[1,2,3]
b=[1,2,3]

a=2
b=2

a="abhaa"
b="kumar"
             # exact  location of object in memory
print(a==b) 
print(a is b)  # value"""

a=None
b=None
print(a is b)
print(a==b)