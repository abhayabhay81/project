"""
a=4
if(a>18):
    print("you are aligible for vote")
else:
    print("you not eligible for vote") 

a = 18
if(a > 18):
    print("you are eligible for vote")
elif(a == 18):
   print("please wate for 1 year")
else:
  print("you are eligible for vote") """
a=1
match(a):
    case 11:
        print("abhay")
    case 12:
        print("aman")
    case 13:
         print("pankaj")
    case 14:
        print("rahul")
    case _:
        print("you are not a persion")