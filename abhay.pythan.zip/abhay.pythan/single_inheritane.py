"""class animal:
    def __init__(self,name,spaces):
        self.name = name
        self.spaces = spaces
        
    def make(self):
        print("sound  made by the animal")
        
class dog(animal):
    def __init__(self, name, bread):
        animal.__init__(self, name, spaces = "dog")
        self.bread = bread
        
    def make(self):
        print("bark!!!!")
        
d = dog("abhay", "yooo")
d.make()

a = animal("gdcgh", "sbyrn")
a.make()
    """
    
    # muliplale inheritance
    
    
        