package abhay1;

public class packej {
    public static void main(String[] args) {

     System.out.println("hey i am abhay an");
    }
}