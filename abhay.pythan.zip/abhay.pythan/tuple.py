"""
tuple1=(1,2,3,4,5,6,7,8)
tuple2=("red","abhay","amna","amit","ajay","arun")

print(tuple1)
print(tuple2)

print(tuple1[3])
print(tuple1[5])
print(tuple1[2])
print(tuple1[1])
print(tuple1[6])

print(tuple2[1])
print(tuple2[2])
print(tuple2[3])
print(tuple2[4])
print(tuple2[5])

print(tuple2[-1])
print(tuple2[-2])
print(tuple2[-3])

print(tuple1[-3])
print(tuple1[-5])
print(tuple1[-2])

print(tuple2[1:3])
print(tuple2[-2:4])
print(tuple2[-3:-2])

print(tuple1[3:4])
print(tuple1[-5:6])
print(tuple1[-2:-5])

print(tuple1[4:])
print(tuple2[:-4])

print(tuple1[-4:])
print(tuple2[:4]

print(tuple1[:1])
print(tuple1[6:])

print(tuple2[::1])
print(tuple2[2:])

print(tuple1[1::])
print(tuple1[-6:4:-3])

print(tuple2[::1])
print(tuple2[2:-5:-2])

print(tuple1[1:3:5])
print(tuple2[1:3:5])

temp=list(tuple1)
temp.append(98)
print(temp)

temp.pop(3)
print(temp)

temp[2]="abhay"
print(temp)

contr=tuple(temp)
print(contr) 

tuple3=tuple1+tuple2
print(tuple3)  """

info=("abhay",20,"am766h")
(name,age,roolnumber)=info
print("name",name)
print("age",age)
print("roolnumber",roolnumber)
