'''def func_name(s):
    return s*2 

print(func_name(10))


 #func_name = lambda x : x*5
 
 print(func_name(10))
 
cube = lambda x: x*x*x
print(cube(10))'''

avr = lambda x , y , z: (x+y+z)/3

print(avr(2,3,4))