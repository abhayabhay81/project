def welcome():
    print("welcome my frind to my program")
 
if __name__=="__main__":
   welcome()