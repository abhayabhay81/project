"""
i=0
for i in range(5):
    print(i)
else:
    print("this is all about for loop")
    
i=0
for i in range(5):
    print(i)
    if i==3:
        print("breake is call")
        break
else:
    print("this is all about for loop")
    
i=0
while i<5:
    print(i)
    i=i+1
    if i==2:
       print("break is call")
       break
else:
  print("breake is not colling")"""
  
i=0
while i<4:
    print("abhay")
    i=i+1
else:
    print("else value is call")