"""
x=100    #globle veriable
def sum():
    global x
 #   x=5  #this will change the value of globle variable
    y=5  #local variable
sum()
print(x)
#print(y)    this is shone errer  """



x=100    #globle veriable
def sum():
 #   x=5  #this will change the value of globle variable
    y=5  #local variable
sum()
print(x)
#print(y)    this is shone errer  """
