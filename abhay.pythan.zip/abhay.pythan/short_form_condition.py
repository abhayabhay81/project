a=input("inter a number")
b=input("inter b number")
#print(a) if a>b  else print(b)
print(a) if a>b else print("=") if a==b else print(b)
