def welcome():
    print("welcome my frind to my program")
    
#welcome()

#abhay="a  good  boy"    