# 1- import math
# 2-from math import sqrt as s
# 3-from math import pi
# 4-from abhay import *
# 4-from abhay import welcome,abhay
import abhay as hr
import math

"""
1-result=math.sqrt(7)
print(result)

2-result=s(9)
print(result)

3-result=pi*6
print(result)

 4-print(dir(math))
print(math.nan,type(math.nan))
welcome()
print(abhay)"""

print(dir(math))
print(math.nan,type(math.nan))
hr.welcome()
print(hr.abhay)