# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Sat Feb 10 10:43:06 2024)---
runfile('C:/Users/abhay/.spyder-py3/temp.py', wdir='C:/Users/abhay/.spyder-py3')

## ---(Sat Feb 10 10:50:11 2024)---
runfile('C:/Users/abhay/.spyder-py3/temp.py', wdir='C:/Users/abhay/.spyder-py3')

## ---(Mon Feb 12 06:11:19 2024)---
debugfile('C:/Users/abhay/untitled7.py', wdir='C:/Users/abhay')

## ---(Tue Mar  5 16:51:40 2024)---
runfile('C:/Users/abhay/abhaypython.py', wdir='C:/Users/abhay')

## ---(Sat Apr  6 18:28:21 2024)---
runfile('C:/Users/abhay/abhaypython.py', wdir='C:/Users/abhay')
67
runfile('C:/Users/abhay/abhaypython.py', wdir='C:/Users/abhay')
i677
76
runfile('C:/Users/abhay/abhaypython.py', wdir='C:/Users/abhay')
runfile('C:/Users/abhay/Downloads/abhay.pythan/abhay.python.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Mon Apr  8 21:02:06 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/abhay1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/abhay1.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/abhay1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Tue Apr  9 21:30:10 2024)---
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled1.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/condition.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/condition.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/condition.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/condition.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/condition.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled2.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/loop.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/loop.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/loop.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/loop.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/loop.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/loop.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled3.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/untitled3.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/function.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Wed Apr 10 07:21:17 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/functon.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Wed Apr 10 17:32:15 2024)---
pip install pyttsx3
pip install speechRecognition
runfile('C:/Users/abhay/Downloads/abhay.pythan/functon.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/list.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/list.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/list.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/loop.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/list.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sat Apr 13 12:00:21 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/list.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sat Apr 13 14:33:14 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/string.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/string.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/string.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/tuple.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sun Apr 14 16:39:42 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/dictionaies.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sun Apr 14 17:41:58 2024)---
runfile('C:/Users/abhay/sets.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/sets.py')
runfile('C:/Users/abhay/sets.py', wdir='C:/Users/abhay')

## ---(Wed Apr 17 06:19:16 2024)---
runfile('C:/Users/abhay/for_and_else.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/for_and_else.py')
runfile('C:/Users/abhay/for_and_else.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/for_and_else.py')
runfile('C:/Users/abhay/for_and_else.py', wdir='C:/Users/abhay')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/exception.py')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
7
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
20
iugg
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
abhay
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')

## ---(Wed Apr 17 07:52:59 2024)---
runcell(0, 'C:/Users/abhay/exception.py')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/exception.py')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/exception.py')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/exception.py')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
jjj
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')

## ---(Wed Apr 17 10:15:31 2024)---
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
runfile('C:/Users/abhay/kbc.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/kbc.py')
runfile('C:/Users/abhay/kbc.py', wdir='C:/Users/abhay')
3
runfile('C:/Users/abhay/kbc.py', wdir='C:/Users/abhay')
3
runfile('C:/Users/abhay/kbc.py', wdir='C:/Users/abhay')
runfile('C:/Users/abhay/exception.py', wdir='C:/Users/abhay')
runfile('C:/Users/abhay/kbc.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/kbc.py')
print(f" \n Q:{i+j} you favourit programing language in your life")
runfile('C:/Users/abhay/kbc.py', wdir='C:/Users/abhay')

## ---(Wed Apr 17 11:51:17 2024)---
runfile('C:/Users/abhay/short_form_condition.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/untitled1.py')
runfile('C:/Users/abhay/enumerate.py', wdir='C:/Users/abhay')
runcell(0, 'C:/Users/abhay/enumerate.py')
runfile('C:/Users/abhay/enumerate.py', wdir='C:/Users/abhay')
pd__version__
print(pd.__version__)
import pandas as pd
print(pd.__version__)
pip3 install pandas

## ---(Wed Apr 17 16:32:18 2024)---
runfile('C:/Users/abhay/.spyder-py3/temp.py', wdir='C:/Users/abhay/.spyder-py3')

## ---(Wed Apr 17 16:44:40 2024)---
runfile('C:/Users/abhay/.spyder-py3/temp.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/working_import.py', wdir='C:/Users/abhay/.spyder-py3')
runcell(0, 'C:/Users/abhay/.spyder-py3/abhay.py')
runfile('C:/Users/abhay/.spyder-py3/working_import.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/abhay.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/if_name_==__main__1.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/abhay2.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/if_name_==__main__1.py', wdir='C:/Users/abhay/.spyder-py3')

## ---(Sat Apr 20 03:15:48 2024)---
runfile('C:/Users/abhay/.spyder-py3/os_module.py', wdir='C:/Users/abhay/.spyder-py3')
runcell(0, 'C:/Users/abhay/.spyder-py3/rename.py')
runfile('C:/Users/abhay/.spyder-py3/rename.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/os_module.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/rename.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/os_module.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/rename.py', wdir='C:/Users/abhay/.spyder-py3')
runfile('C:/Users/abhay/.spyder-py3/os module/cont_os_list.py', wdir='C:/Users/abhay/.spyder-py3/os module')
runcell(0, 'C:/Users/abhay/.spyder-py3/os module/cont_os_list.py')
runfile('C:/Users/abhay/.spyder-py3/os module/cont_os_list.py', wdir='C:/Users/abhay/.spyder-py3/os module')
runfile('C:/Users/abhay/.spyder-py3/os module/os_module.py', wdir='C:/Users/abhay/.spyder-py3/os module')
runfile('C:/Users/abhay/.spyder-py3/os module/cont_os_list.py', wdir='C:/Users/abhay/.spyder-py3/os module')
runcell(0, 'C:/Users/abhay/.spyder-py3/os module/cont_os_list.py')
runfile('C:/Users/abhay/.spyder-py3/os module/cont_os_list.py', wdir='C:/Users/abhay/.spyder-py3/os module')

## ---(Sat Apr 20 07:58:46 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
bbb
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/exercise1.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
hbh
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise1.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sat Apr 20 17:17:06 2024)---
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled0.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/variable.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/file_handling.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/myfile2.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/file_handling.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/file_handling.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/file_handling.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sun Apr 21 10:31:58 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/file_handling.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/file_handling.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/file_handling.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sun Apr 21 11:29:04 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/lemda_fun.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled1.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/map.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/is_==.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/class_object.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/cponstructor.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Sun Apr 21 14:45:29 2024)---
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled0.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/decoretors.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/geter_seter.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')

## ---(Mon Apr 22 10:13:25 2024)---
runfile('C:/Users/abhay/Downloads/abhay.pythan/inheritance.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise2.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
1
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise2.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/stactic method.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/exercise3.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/class method.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runfile('C:/Users/abhay/Downloads/abhay.pythan/dir_dict_help.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')
runcell(0, 'C:/Users/abhay/Downloads/abhay.pythan/untitled7.py')
runfile('C:/Users/abhay/Downloads/abhay.pythan/super_keyward.py', wdir='C:/Users/abhay/Downloads/abhay.pythan')