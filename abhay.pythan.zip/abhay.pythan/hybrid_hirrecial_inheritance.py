"""
  #hybride inheritance
  
class base1:
    pass
class base2(base1):
    pass
class base3(base1):
    pass
class base4(base2,base3):
    pass"""
    
    # hirrcial inheritance
    
class base1:
    pass
class base2(base1):
    pass
class base3(base1):
    pass
class base4(base2):
    pass