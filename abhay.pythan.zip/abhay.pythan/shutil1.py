import shutil
import os
"""
shutil.copy("shutil1.py","shutil2.py")
shutil.copytree("abhay.pythan","abhaypythan2") # this is use for copy the content of folder to create new folder
shutil.move("abhay.pythan/exercise1.py", "exercise1.py")"""
os.remove("filename")

