
"""
a=5
while(a<6):
    print(a)
    a=a+1

for i in range(7):
    print("abhay") """
 
#name=["abhay","ram","rajeev","aman","asmit","prine"]
name=[11,12,13,14,15,17,16]
for i in name:
    print(i)
    

