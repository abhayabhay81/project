from music_dounder import employee

e = employee("pankaj")
print(str(e))
print(repr(e))
e()  # is calling __call__(self)

#print(len(e))